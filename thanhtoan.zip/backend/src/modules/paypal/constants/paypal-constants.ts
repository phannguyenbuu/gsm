export const PAYPAL_AXIOS_INSTANCE_TOKEN = 'paypal_axios_instance_token';
export const PAYPAL_AUTHORIZATION_SERVICE_INSTANCE_TOKEN = 'paypal_authorization_service_token';
export const PAYPAL_PAYMENT_SERVICE_INSTANCE_TOKEN = 'paypal_payment_service_token';
export const PAYPAL_UTILS_SERVICE_INSTANCE_TOKEN = 'paypal_utils_service_token';
export const PAYPAL_MODULE_OPTIONS = 'paypal_module_options';
export const PAYPAL_AUTHORIZATION_HEADERS = {
  'Content-Type': 'application/x-www-form-urlencoded'
};

