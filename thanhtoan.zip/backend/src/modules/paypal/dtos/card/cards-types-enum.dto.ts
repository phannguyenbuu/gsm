

export enum CardsTypesEnumDto {
  CREDIT,
  DEBIT,
  PREPAID,
  UNKNOWN
}