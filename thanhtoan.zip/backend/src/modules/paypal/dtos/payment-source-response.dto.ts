import { CardResponseDto } from "../dtos";


export class PaymentSourceResponseDto {
  card: CardResponseDto;
}