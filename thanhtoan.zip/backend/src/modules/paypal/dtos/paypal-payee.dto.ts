


export class PaypalPayeeBaseDto {
  email_address: string;
  merchant_id: string;
}
export class PaypalPayeeDto extends PaypalPayeeBaseDto {

}