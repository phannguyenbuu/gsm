

export enum PaypalStoredPaymentSourcePaymentTypeDto {
  'ONE_TIME' , 'RECURRING' , 'UNSCHEDULED'
}