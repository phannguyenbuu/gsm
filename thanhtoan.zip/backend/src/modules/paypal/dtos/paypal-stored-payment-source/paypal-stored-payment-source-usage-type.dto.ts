export enum PaypalStoredPaymentSourceUsageTypeDto {
  'FIRST', 'SUBSEQUENT', 'DERIVED'
}