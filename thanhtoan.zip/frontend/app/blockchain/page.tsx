import BlockchainPaymentTest from '../../src/components/BlockchainPaymentTest';

export default function Home() {
  return <BlockchainPaymentTest />;
}