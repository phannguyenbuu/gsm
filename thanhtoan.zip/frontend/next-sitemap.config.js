module.exports = {
  siteUrl: 'https://your-domain.com',
  generateRobotsTxt: true,
  sitemapSize: 5000,
}
